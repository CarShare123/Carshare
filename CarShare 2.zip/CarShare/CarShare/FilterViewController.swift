//
//  FilterViewController.swift
//  CarShare
//
//  Created by Kala Branch on 4/11/21.
//

import UIKit

class FilterViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countries.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countries[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickupLocationtxt.text = countries[row]
        pickupLocationtxt.resignFirstResponder()
    }

    @IBOutlet weak var pickup: UITextField!
    
    @IBOutlet weak var dropOff: UITextField!
    
    
    @IBOutlet weak var pickupLocationtxt: UITextField!
    //pickup Locations
    let countries = ["Huntsville", "Birminghan", "Nashville", "Memphis", "Atlanta"]
    var pickerView = UIPickerView()
    
    let datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createDatePicker()
        // Do any additional setup after loading the view.
        
        pickerView.delegate = self
        pickerView.dataSource = self
        
        pickupLocationtxt.inputView = pickerView
        pickupLocationtxt.textAlignment = .center
    }
    

    
    
    func createDatePicker(){
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated: true)
        
        pickup.inputAccessoryView = toolbar
        dropOff.inputAccessoryView = toolbar
        
        pickup.inputView = datePicker
        
        dropOff.inputView = datePicker
        
        datePicker.datePickerMode = .date
    }
    
    @objc func donePressed() {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        
        pickup.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
        
        dropOff.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


